package beernet;

public class BadSecretException extends Exception{
	public BadSecretException(String txt){
		super(txt);
	}
}
