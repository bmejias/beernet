package beernet;

public class NoSetException extends Exception {

	public NoSetException(String string) {
		super(string);
	}

}
