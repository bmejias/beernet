package beernet;

public class ValueNotFoundException extends Exception{
	public ValueNotFoundException(String txt){
		super(txt);
	}
}
