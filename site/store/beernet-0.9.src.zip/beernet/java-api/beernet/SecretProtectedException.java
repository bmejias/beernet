package beernet;

public class SecretProtectedException extends Exception{
	public SecretProtectedException(String txt){
		super(txt);
	}
}
