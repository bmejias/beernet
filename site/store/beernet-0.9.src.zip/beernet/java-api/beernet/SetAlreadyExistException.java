package beernet;

public class SetAlreadyExistException extends Exception {

	public SetAlreadyExistException(String string) {
		super(string);
	}

}
